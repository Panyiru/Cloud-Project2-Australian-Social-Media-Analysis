from django.http import JsonResponse
from django.shortcuts import render
import couchdb


couchserver = couchdb.Server("http://115.146.86.136:5986/")

db = couchserver['tweet']

time_view_doc = 'time_data'
hours_view = 'hours'
week_days_view = 'week_days'


sentiment_view_doc = 'sentiment'
total_sentiment_view = 'total_sentiment'


area_view = 'sa2_data'
area_sentiment_view = 'sa2_sentiment'


def index(request):
    return render(request, 'index.html')



def hourly_data(request):
    rows = db.view(time_view_doc + '/' + hours_view, group=True, stale='ok')
    resp = {}
    for row in rows:
        resp[row.key] = row.value

    return JsonResponse(resp, safe=False)


def week_days_data(request):
    rows = db.view(time_view_doc + '/' + week_days_view, group=True, stale='ok')
    resp = {}
    for row in rows:
        resp[row.key] = row.value

    return JsonResponse(resp, safe=False)


def total_sentiment(request):

    rows = db.view(sentiment_view_doc + '/' + total_sentiment_view, group=True, stale='ok')
    resp = {}
    for row in rows:
        resp[row.key] = row.value

    return JsonResponse(resp, safe=False)

def per_area(request):
    rows = db.view(area_view + '/' + area_sentiment_view, group=True, stale='ok')
    resp = {}
    for row in rows:
        resp[row.key] = row.value
    return JsonResponse(resp,safe=True)